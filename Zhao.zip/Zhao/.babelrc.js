module.exports = {
  presets: ['@babel/typescript', '@babel/preset-env', '@babel/preset-react'],
  plugins: ['@babel/plugin-proposal-class-properties'],
};