export const mainBlock: string;
export const wrongText: string;
export const image: string;
